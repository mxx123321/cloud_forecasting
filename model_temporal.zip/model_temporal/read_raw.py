import numpy as np
import matplotlib.pyplot as plt
import os

# ================= 配置路径 =================
RAW_FILE_PATH = "/data4/mxx_new_code/fengyun_mxx/Table/FY4B-_DISK_1050E_GEO_NOM_LUT_20240227000000_4000M_V0001.raw"
DIM = 2748 

def inspect_raw_file():
    if not os.path.exists(RAW_FILE_PATH):
        print(f"错误: 找不到文件 {RAW_FILE_PATH}")
        return

    print(f"读取文件: {RAW_FILE_PATH}")
    # 卫星数据通常使用 double (float64)
    raw_data = np.fromfile(RAW_FILE_PATH, dtype=np.float64)
    
    # 定义 Planar 解析 (这是最可能的格式)
    # 拆分前一半和后一半
    part1 = raw_data[:DIM*DIM].reshape(DIM, DIM)
    part2 = raw_data[DIM*DIM:2*DIM*DIM].reshape(DIM, DIM)

    plt.figure(figsize=(16, 12))

    # --- 组合 1: 假设是 [纬度, 经度] ---
    plt.subplot(2, 2, 1)
    plt.imshow(part1, cmap='RdBu_r')
    plt.title("Planar Set 1 (Assuming Latitude)")
    plt.colorbar()

    plt.subplot(2, 2, 2)
    plt.imshow(part2, cmap='RdBu_r')
    plt.title("Planar Set 2 (Assuming Longitude)")
    plt.colorbar()

    # --- 组合 2: 尝试交错模式 (Interleaved) ---
    lat_i = raw_data[0:DIM*DIM*2:2].reshape(DIM, DIM)
    lon_i = raw_data[1:DIM*DIM*2:2].reshape(DIM, DIM)
    
    plt.subplot(2, 2, 3)
    plt.imshow(lat_i, cmap='RdBu_r')
    plt.title("Interleaved Set 1")
    plt.colorbar()

    plt.subplot(2, 2, 4)
    plt.imshow(lon_i, cmap='RdBu_r')
    plt.title("Interleaved Set 2")
    plt.colorbar()

    plt.tight_layout()
    plt.savefig("final_raw_check.png")
    
    mid = DIM // 2
    print("\n--- 采样点分析 (1374, 1374) ---")
    print(f"Planar Set 1: {part1[mid, mid]:.4f}")
    print(f"Planar Set 2: {part2[mid, mid]:.4f}")
    print(f"Interleaved Set 1: {lat_i[mid, mid]:.4f}")
    print(f"Interleaved Set 2: {lon_i[mid, mid]:.4f}")
    
    # 统计有效范围
    valid_p1 = np.sum((part1 > -90) & (part1 < 90)) / (DIM*DIM)
    print(f"Planar Set 1 合法比例 (范围-90~90): {valid_p1:.2%}")

if __name__ == "__main__":
    inspect_raw_file()