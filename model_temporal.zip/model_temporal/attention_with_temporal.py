import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.fft

class FreqAggregator(nn.Module):
    def __init__(self, dim, h, w, dropout=0.1):
        super().__init__()
        self.dim = dim
        self.h = h
        self.w = w
        
        # 定义频谱存储池：分别存储幅度权重和相位权重
        # rfft2 输出大小: (H, W // 2 + 1)
        self.complex_weight = nn.Parameter(
            torch.randn(1, dim, h, w // 2 + 1, 2, dtype=torch.float32) * 0.02
        )
        
        # 动态门控生成器：从 Global Token 提取上下文，用于调制频谱
        self.context_gate = nn.Sequential(
            nn.Linear(dim, dim // 4),
            nn.GELU(),
            nn.Linear(dim // 4, dim * 2), # 一半给幅度，一半给相位
            nn.Sigmoid()
        )
        
        self.proj = nn.Linear(dim, dim)
        self.norm = nn.LayerNorm(dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, glb):
        B, C, H, W = x.shape
        
        # Step 1: 正交快速傅里叶变换 (保持能量守恒)
        x_fft = torch.fft.rfft2(x.float(), norm='ortho')
        x_amp = torch.abs(x_fft)   # 振幅：代表能量/特征强度
        x_phase = torch.angle(x_fft) # 相位：代表空间位置/结构信息

        # Step 2: 获取并对齐频谱模版
        weight = torch.view_as_complex(self.complex_weight)
        if weight.shape[2] != x_fft.shape[2] or weight.shape[3] != x_fft.shape[3]:
            # 采用频谱重采样插值
            weight = F.interpolate(
                torch.view_as_real(weight).permute(0, 3, 1, 2),
                size=(x_fft.shape[2], x_fft.shape[3]),
                mode='bilinear', align_corners=True
            ).permute(0, 2, 3, 1).contiguous()
            weight = torch.view_as_complex(weight)

        # Step 3: 上下文感知的自适应调制 (Decoupled Modulation)
        # 生成动态开关控制
        gates = self.context_gate(glb).unsqueeze(-1).unsqueeze(-1) # (B, 1, 2C, 1, 1)
        amp_gate, phase_gate = torch.split(gates, self.dim, dim=2)
        
        # 3.1 振幅增强：学习“哪些尺度的云层需要被关注”
        # 使用残差结构: amp = amp * (1 + weight_amp * gate)
        target_amp = x_amp * (1 + torch.abs(weight) * (amp_gate.transpose(1, 2) * 2 - 1))
        
        # 3.2 相位偏移：学习“云层的动力学平移”
        # 相位是周期性的，通过加法实现偏移
        target_phase = x_phase + torch.angle(weight) * phase_gate.transpose(1, 2)

        # Step 4: 极坐标系下的特征重组
        res_fft = torch.polar(target_amp, target_phase)

        # Step 5: 逆变换回空域 & 递归更新 Global Token
        res = torch.fft.irfft2(res_fft, s=(H, W), norm='ortho')
        
        # 提取演化增量 (Evolutionary Increment)
        update = F.adaptive_avg_pool2d(res, (1, 1)).flatten(1).unsqueeze(1)
        update = self.proj(update)
        
        glb = self.norm(glb + self.dropout(update))
        return glb

class RSTDAttention(nn.Module):
    def __init__(self, dim, h, w, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0., sr_ratio=1):
        super().__init__()
        self.dim = dim
        self.num_heads = num_heads
        self.scale = qk_scale or (dim // num_heads) ** -0.5

        # Learnable Global Latent Token
        self.glb_token = nn.Parameter(torch.randn(1, 1, dim))
        nn.init.trunc_normal_(self.glb_token, std=.02)
        
        # 集成 ASDO (Adaptive Spectral Dynamics Operator)
        self.asdo = FreqAggregator(dim, h, w)

        self.q = nn.Linear(dim, dim, bias=qkv_bias)
        self.kv = nn.Linear(dim, dim * 2, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

        self.sr_ratio = sr_ratio
        if sr_ratio > 1:
            self.sr = nn.Conv2d(dim, dim, kernel_size=sr_ratio, stride=sr_ratio)
            self.norm = nn.LayerNorm(dim)

    def forward(self, x):
        B, C, H, W = x.shape
        N = H * W

        # 1. 频域动力学聚合: ASDO 更新 Global Token
        glb = self.glb_token.expand(B, -1, -1)
        glb = self.asdo(x, glb) 

        # 2. 时空域 Attention: 双向交互 (Cross-Domain Interaction)
        x_flat = x.flatten(2).transpose(1, 2)
        x_q_in = torch.cat([x_flat, glb], dim=1) 
        
        q = self.q(x_q_in).reshape(B, N + 1, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)

        if self.sr_ratio > 1:
            x_kv = self.norm(self.sr(x).reshape(B, C, -1).permute(0, 2, 1))
            glb_kv = self.norm(glb) 
            x_kv_in = torch.cat([x_kv, glb_kv], dim=1)
        else:
            x_kv_in = x_q_in
            
        kv = self.kv(x_kv_in).reshape(B, -1, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        k, v = kv[0], kv[1]

        # 3. 自注意力计算
        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)

        x_out = (attn @ v).transpose(1, 2).reshape(B, N + 1, C)
        x_out = self.proj(x_out)
        x_out = self.proj_drop(x_out)

        # 4. 抽离结果
        x_spatial = x_out[:, :-1, :].transpose(1, 2).reshape(B, C, H, W)
        return x_spatial