import os
import copy
import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from typing import Dict
import itertools
import torch.fft 

from timm.data import IMAGENET_DEFAULT_MEAN, IMAGENET_DEFAULT_STD
from timm.models.layers import DropPath, trunc_normal_
from timm.models.registry import register_model
from timm.models.layers import to_2tuple

# -----------------------------------------------------------------------
#  Part 1: 频域注意力机制
# -----------------------------------------------------------------------

class FreqAggregator(nn.Module):
    def __init__(self, dim, h, w, dropout=0.):
        super().__init__()
        self.dim = dim
        self.h = h
        self.w = w
        
        self.freq_weight = nn.Parameter(
            torch.randn(1, dim, h, w // 2 + 1, 2, dtype=torch.float32) * 0.02
        )
        
        self.proj = nn.Linear(dim, dim)
        self.norm = nn.LayerNorm(dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, glb):
        B, C, H, W = x.shape
        x_fft = torch.fft.rfft2(x.float(), norm='ortho')
        weight = torch.view_as_complex(self.freq_weight)
        
        current_h, current_w_half = x_fft.shape[2], x_fft.shape[3]
        if weight.shape[2] != current_h or weight.shape[3] != current_w_half:
            weight = F.interpolate(
                torch.view_as_real(weight).permute(0, 3, 1, 2), 
                size=(current_h, current_w_half), 
                mode='bilinear', 
                align_corners=True
            ).permute(0, 2, 3, 1).contiguous()
            weight = torch.view_as_complex(weight)

        glb_gate = glb.transpose(1, 2).unsqueeze(-1)
        inf_fft = weight * glb_gate
        res_fft = x_fft * inf_fft
        res = torch.fft.irfft2(res_fft, s=(H, W), norm='ortho')
        update = res.mean(dim=(2, 3)).unsqueeze(1)
        update = self.proj(update)
        glb = self.norm(glb + self.dropout(update))
        return glb


class FreqAttention(nn.Module):
    def __init__(self, dim, h, w, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0., sr_ratio=1):
        super().__init__()
        if dim % num_heads != 0:
            pass 
        
        self.dim = dim
        self.num_heads = num_heads
        self.scale = qk_scale or (dim // num_heads) ** -0.5

        self.glb_token = nn.Parameter(torch.randn(1, 1, dim))
        trunc_normal_(self.glb_token, std=.02)
        
        self.freq_aggregator = FreqAggregator(dim, h, w)

        self.q = nn.Linear(dim, dim, bias=qkv_bias)
        self.kv = nn.Linear(dim, dim * 2, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

        self.sr_ratio = sr_ratio
        if sr_ratio > 1:
            self.sr = nn.Conv2d(dim, dim, kernel_size=sr_ratio, stride=sr_ratio)
            self.norm = nn.LayerNorm(dim)

    def forward(self, x):
        B, C, H, W = x.shape
        N = H * W
        glb = self.glb_token.expand(B, -1, -1) 
        glb = self.freq_aggregator(x, glb) 
        x_flat = x.flatten(2).transpose(1, 2) 
        x_q_in = torch.cat([x_flat, glb], dim=1) 
        
        q = self.q(x_q_in).reshape(B, N + 1, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)

        if self.sr_ratio > 1:
            x_ = self.sr(x) 
            x_ = x_.reshape(B, C, -1).permute(0, 2, 1)
            x_ = self.norm(x_)
            glb_norm = self.norm(glb) 
            x_kv_in = torch.cat([x_, glb_norm], dim=1)
        else:
            x_kv_in = x_q_in
            
        kv = self.kv(x_kv_in).reshape(B, -1, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        k, v = kv[0], kv[1]

        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)

        x_out = (attn @ v).transpose(1, 2).reshape(B, N + 1, C)
        x_out = self.proj(x_out)
        x_out = self.proj_drop(x_out)

        x_spatial = x_out[:, :-1, :] 
        x_spatial = x_spatial.transpose(1, 2).reshape(B, C, H, W)

        return x_spatial

# -----------------------------------------------------------------------
#  Part 2: 适配层
# -----------------------------------------------------------------------

class FreqAttentionDownsample(nn.Module):
    def __init__(self, dim=384, out_dim=None, resolution=32, act_layer=nn.ReLU, **kwargs):
        super().__init__()
        self.out_dim = out_dim if out_dim is not None else dim
        num_heads = 8
        if dim % num_heads != 0:
            num_heads = 4
        self.attn = FreqAttention(dim=dim, h=resolution, w=resolution, num_heads=num_heads)
        self.downsample = nn.Sequential(
            act_layer() if act_layer else nn.Identity(),
            nn.Conv2d(dim, self.out_dim, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(self.out_dim)
        )

    def forward(self, x):
        x = self.attn(x)
        x = self.downsample(x)
        return x

class FreqAttentionUpsample(nn.Module):
    def __init__(self, dim=384, out_dim=None, resolution=32, resolution2=None, act_layer=nn.ReLU, **kwargs):
        super().__init__()
        self.out_dim = out_dim if out_dim is not None else dim
        target_res = resolution2 if resolution2 is not None else resolution * 2
        self.upsample = nn.Sequential(
            nn.ConvTranspose2d(dim, self.out_dim, kernel_size=3, stride=2, padding=1, output_padding=1),
            nn.BatchNorm2d(self.out_dim),
            act_layer() if act_layer else nn.Identity()
        )
        num_heads = 8
        if self.out_dim % num_heads != 0:
            num_heads = 4
        self.attn = FreqAttention(dim=self.out_dim, h=target_res, w=target_res, num_heads=num_heads)

    def forward(self, x):
        x = self.upsample(x)
        x = self.attn(x)
        return x


# -----------------------------------------------------------------------
#  Part 3: 原始 U-Net 结构
# -----------------------------------------------------------------------

def stem(in_chs, out_chs, act_layer=nn.ReLU):
    return nn.Sequential(
        nn.Conv2d(in_chs, out_chs // 2, kernel_size=3, stride=2, padding=1),
        nn.BatchNorm2d(out_chs // 2),
        act_layer(),
        nn.Conv2d(out_chs // 2, out_chs, kernel_size=3, stride=2, padding=1),
        nn.BatchNorm2d(out_chs),
        act_layer(),
    )

def merge(in_chs, out_chs, act_layer=nn.ReLU):
    return nn.Sequential(
        nn.ConvTranspose2d(in_chs, out_chs // 2, kernel_size=3, stride=2, padding=1, output_padding=1),
        nn.BatchNorm2d(out_chs // 2),
        act_layer(),
        nn.ConvTranspose2d(out_chs // 2, out_chs, kernel_size=3, stride=2, padding=1, output_padding=1),
        nn.BatchNorm2d(out_chs),
        act_layer(),
    )

class Embedding(nn.Module):
    def __init__(self, patch_size=3, stride=2, padding=1,
                 in_chans=3, embed_dim=768, norm_layer=nn.BatchNorm2d,
                 light=False, asub=False, resolution=None, act_layer=nn.ReLU, 
                 attn_block=FreqAttentionDownsample):
        super().__init__()
        self.light = light
        self.asub = asub

        if self.light:
            self.new_proj = nn.Sequential(
                nn.Conv2d(in_chans, in_chans, kernel_size=3, stride=2, padding=1, groups=in_chans),
                nn.BatchNorm2d(in_chans),
                nn.Hardswish(),
                nn.Conv2d(in_chans, embed_dim, kernel_size=1, stride=1, padding=0),
                nn.BatchNorm2d(embed_dim),
            )
            self.skip = nn.Sequential(
                nn.Conv2d(in_chans, embed_dim, kernel_size=1, stride=2, padding=0),
                nn.BatchNorm2d(embed_dim)
            )
        elif self.asub:
            self.attn = attn_block(dim=in_chans, out_dim=embed_dim,
                                   resolution=resolution, act_layer=act_layer)
            
            patch_size = to_2tuple(patch_size)
            stride = to_2tuple(stride)
            padding = to_2tuple(padding)
            self.conv = nn.Conv2d(in_chans, embed_dim, kernel_size=patch_size,
                                  stride=stride, padding=padding)
            self.bn = norm_layer(embed_dim) if norm_layer else nn.Identity()
        else:
            patch_size = to_2tuple(patch_size)
            stride = to_2tuple(stride)
            padding = to_2tuple(padding)
            self.proj = nn.Conv2d(in_chans, embed_dim, kernel_size=patch_size,
                                  stride=stride, padding=padding)
            self.norm = norm_layer(embed_dim) if norm_layer else nn.Identity()

    def forward(self, x):
        if self.light:
            out = self.new_proj(x) + self.skip(x)
        elif self.asub:
            out_conv = self.conv(x)
            out_conv = self.bn(out_conv)
            out = self.attn(x) + out_conv
        else:
            x = self.proj(x)
            out = self.norm(x)
        return out

class Expanding(nn.Module):
    def __init__(self, patch_size=2, stride=2, padding=1,
                 in_chans=3, embed_dim=768, norm_layer=nn.BatchNorm2d,
                 light=False, asub=False, resolution=None, resolution2=None, act_layer=nn.ReLU,
                 attn_block=FreqAttentionUpsample):
        super().__init__()
        self.light = light
        self.asub = asub
        
        if self.light:
            self.new_proj = nn.Sequential(
                nn.ConvTranspose2d(in_chans, in_chans, kernel_size=3, stride=2, padding=1, output_padding=1, groups=in_chans),
                nn.BatchNorm2d(in_chans),
                nn.Hardswish(),
                nn.Conv2d(in_chans, embed_dim, kernel_size=1, stride=1, padding=0),
                nn.BatchNorm2d(embed_dim),
            )
            self.skip = nn.Sequential(
                nn.ConvTranspose2d(in_chans, embed_dim, kernel_size=3, stride=2, padding=1, output_padding=1),
                nn.BatchNorm2d(embed_dim),
            )
        elif self.asub:
            self.attn = attn_block(dim=in_chans, out_dim=embed_dim,
                                   resolution=resolution, resolution2=resolution2, act_layer=act_layer)
            patch_size = (patch_size, patch_size)
            stride = (stride, stride)
            padding = (padding, padding)
            self.conv = nn.ConvTranspose2d(in_chans, embed_dim, kernel_size=patch_size, stride=stride, padding=padding, output_padding=1)
            self.bn = norm_layer(embed_dim) if norm_layer else nn.Identity()
        else:
            patch_size = (patch_size, patch_size)
            stride = (stride, stride)
            padding = (padding, padding)
            self.proj = nn.ConvTranspose2d(in_chans, embed_dim, kernel_size=patch_size, stride=stride, padding=padding, output_padding=1)
            self.norm = norm_layer(embed_dim) if norm_layer else nn.Identity()
    
    def forward(self, x):
        if self.light:
            out = self.new_proj(x) + self.skip(x)
        elif self.asub:
            out_conv = self.conv(x)
            out_conv = self.bn(out_conv)
            out = self.attn(x) + out_conv
        else:
            x = self.proj(x)
            out = self.norm(x)

        return out
    
class Mlp(nn.Module):
    def __init__(self, in_features, hidden_features=None,
                 out_features=None, act_layer=nn.GELU, drop=0., mid_conv=False):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.mid_conv = mid_conv
        self.fc1 = nn.Conv2d(in_features, hidden_features, 1)
        self.act = act_layer()
        self.fc2 = nn.Conv2d(hidden_features, out_features, 1)
        self.drop = nn.Dropout(drop)
        self.apply(self._init_weights)

        if self.mid_conv:
            self.mid = nn.Conv2d(hidden_features, hidden_features, kernel_size=3, stride=1, padding=1,
                                 groups=hidden_features)
            self.mid_norm = nn.BatchNorm2d(hidden_features)

        self.norm1 = nn.BatchNorm2d(hidden_features)
        self.norm2 = nn.BatchNorm2d(out_features)

    def _init_weights(self, m):
        if isinstance(m, nn.Conv2d):
            trunc_normal_(m.weight, std=.02)
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)

    def forward(self, x):
        x = self.fc1(x)
        x = self.norm1(x)
        x = self.act(x)

        if self.mid_conv:
            x_mid = self.mid(x)
            x_mid = self.mid_norm(x_mid)
            x = self.act(x_mid)
        x = self.drop(x)

        x = self.fc2(x)
        x = self.norm2(x)

        x = self.drop(x)
        return x

class AttnFFN(nn.Module):
    def __init__(self, dim, mlp_ratio=4.,
                 act_layer=nn.ReLU, norm_layer=nn.LayerNorm,
                 drop=0., drop_path=0.,
                 use_layer_scale=True, layer_scale_init_value=1e-5,
                 resolution=7, stride=None):

        super().__init__()
        num_heads = 8
        if dim % num_heads != 0: num_heads = 4 

        self.token_mixer = FreqAttention(dim, h=resolution, w=resolution, num_heads=num_heads)
        
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = Mlp(in_features=dim, hidden_features=mlp_hidden_dim,
                       act_layer=act_layer, drop=drop, mid_conv=True)

        self.drop_path = DropPath(drop_path) if drop_path > 0. \
            else nn.Identity()
        self.use_layer_scale = use_layer_scale
        if use_layer_scale:
            self.layer_scale_1 = nn.Parameter(
                layer_scale_init_value * torch.ones(dim).unsqueeze(-1).unsqueeze(-1), requires_grad=True)
            self.layer_scale_2 = nn.Parameter(
                layer_scale_init_value * torch.ones(dim).unsqueeze(-1).unsqueeze(-1), requires_grad=True)

    def forward(self, x):
        if self.use_layer_scale:
            x = x + self.drop_path(self.layer_scale_1 * self.token_mixer(x))
            x = x + self.drop_path(self.layer_scale_2 * self.mlp(x))

        else:
            x = x + self.drop_path(self.token_mixer(x))
            x = x + self.drop_path(self.mlp(x))
        return x

class FFN(nn.Module):
    def __init__(self, dim, pool_size=3, mlp_ratio=4.,
                 act_layer=nn.GELU,
                 drop=0., drop_path=0.,
                 use_layer_scale=True, layer_scale_init_value=1e-5):
        super().__init__()

        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = Mlp(in_features=dim, hidden_features=mlp_hidden_dim,
                       act_layer=act_layer, drop=drop, mid_conv=True)

        self.drop_path = DropPath(drop_path) if drop_path > 0. \
            else nn.Identity()
        self.use_layer_scale = use_layer_scale
        if use_layer_scale:
            self.layer_scale_2 = nn.Parameter(
                layer_scale_init_value * torch.ones(dim).unsqueeze(-1).unsqueeze(-1), requires_grad=True)

    def forward(self, x):
        if self.use_layer_scale:
            x = x + self.drop_path(self.layer_scale_2 * self.mlp(x))
        else:
            x = x + self.drop_path(self.mlp(x))
        return x


def eformer_block(dim, index, layers,
                  pool_size=3, mlp_ratio=4.,
                  act_layer=nn.GELU, norm_layer=nn.LayerNorm,
                  drop_rate=.0, drop_path_rate=0.,
                  use_layer_scale=True, layer_scale_init_value=1e-5, vit_num=1, resolution=7, e_ratios=None):
    blocks = []
    for block_idx in range(layers[index]):
        block_dpr = drop_path_rate * (
                block_idx + sum(layers[:index])) / (sum(layers) - 1)
        mlp_ratio = e_ratios[str(index)][block_idx]
        if index >= 2 and block_idx > layers[index] - 1 - vit_num:
            if index == 2:
                stride = 2
            else:
                stride = None
            blocks.append(AttnFFN(
                dim, mlp_ratio=mlp_ratio,
                act_layer=act_layer, norm_layer=norm_layer,
                drop=drop_rate, drop_path=block_dpr,
                use_layer_scale=use_layer_scale,
                layer_scale_init_value=layer_scale_init_value,
                resolution=resolution,
                stride=stride,
            ))
        else:
            blocks.append(FFN(
                dim, pool_size=pool_size, mlp_ratio=mlp_ratio,
                act_layer=act_layer,
                drop=drop_rate, drop_path=block_dpr,
                use_layer_scale=use_layer_scale,
                layer_scale_init_value=layer_scale_init_value,
            ))
    blocks = nn.Sequential(*blocks)
    return blocks

def eformer_block_up(dim, index, layers,
                  pool_size=3, mlp_ratio=4.,
                  act_layer=nn.GELU, norm_layer=nn.LayerNorm,
                  drop_rate=.0, drop_path_rate=0.,
                  use_layer_scale=True, layer_scale_init_value=1e-5, vit_num=1, resolution=7, e_ratios=None):
    blocks = []
    for block_idx in range(layers[index]):
        block_dpr = drop_path_rate * (
                block_idx + sum(layers[index+1:])) / (sum(layers) - 1)
        mlp_ratio = e_ratios[str(index)][block_idx]
        if index <= 1 and block_idx > layers[index] - 1 - vit_num:
            if index == 1:
                stride = 2
            else:
                stride = None
            blocks.append(AttnFFN(
                dim, mlp_ratio=mlp_ratio,
                act_layer=act_layer, norm_layer=norm_layer,
                drop=drop_rate, drop_path=block_dpr,
                use_layer_scale=use_layer_scale,
                layer_scale_init_value=layer_scale_init_value,
                resolution=resolution,
                stride=stride,
            ))
        else:
            blocks.append(FFN(
                dim, pool_size=pool_size, mlp_ratio=mlp_ratio,
                act_layer=act_layer,
                drop=drop_rate, drop_path=block_dpr,
                use_layer_scale=use_layer_scale,
                layer_scale_init_value=layer_scale_init_value,
            ))
    blocks = nn.Sequential(*blocks)
    return blocks

class Flatten(nn.Module):
    def forward(self, x):
        return x.view(x.size(0), -1)

# [这里原有的 CCA 类已被删除]

class Eff_Unet(nn.Module):
    def __init__(self, layers, embed_dims=None,
                 mlp_ratios=4,
                 downsamples=None,
                 pool_size=3,
                 norm_layer=nn.BatchNorm2d, act_layer=nn.GELU,
                 num_classes=9,
                 down_patch_size=3, down_stride=2, down_pad=1,
                 drop_rate=0., drop_path_rate=0.,
                 use_layer_scale=True, layer_scale_init_value=1e-5,
                 init_cfg=None,
                 pretrained=None,
                 vit_num=1,
                 distillation=True,
                 resolution=224,
                 stem_channel=3,
                 **kwargs):
        super().__init__()

        self.num_classes = num_classes
        self.stem_channel = stem_channel
        self.patch_embed = stem(stem_channel, embed_dims[0], act_layer=act_layer)
        self.up = merge(embed_dims[0],embed_dims[0], act_layer=act_layer)
        self.output = nn.Conv2d(in_channels=embed_dims[0],out_channels=self.num_classes,kernel_size=1,bias=False)
    
        if isinstance(mlp_ratios, (int, float)):
            self.e_ratios = {
                str(i): [mlp_ratios] * num_blocks 
                for i, num_blocks in enumerate(layers)
            }
        else:
            self.e_ratios = mlp_ratios

        layers_reverse = layers[::-1]
        
        if isinstance(mlp_ratios, (int, float)):
            self.e_ratios_reverse = {
                str(i): [mlp_ratios] * num_blocks 
                for i, num_blocks in enumerate(layers_reverse)
            }
        else:
            self.e_ratios_reverse = {
                str(i): [4] * num_blocks 
                for i, num_blocks in enumerate(layers_reverse)
            }

        network_down = []
        res_arr = []
        if self.num_classes == 1:
            self.sig = nn.Sigmoid()    

        for i in range(len(layers)):
            res=math.ceil(resolution / (2 ** (i + 2)))
            res_arr.append(res)
            
            stage = eformer_block(embed_dims[i], i, layers,
                                  pool_size=pool_size, mlp_ratio=mlp_ratios,
                                  act_layer=act_layer, norm_layer=norm_layer,
                                  drop_rate=drop_rate,
                                  drop_path_rate=drop_path_rate,
                                  use_layer_scale=use_layer_scale,
                                  layer_scale_init_value=layer_scale_init_value,
                                  resolution=res,
                                  vit_num=vit_num,
                                  e_ratios=self.e_ratios)
            network_down.append(stage)

            if i >= len(layers) - 1:
                break
            if downsamples[i] or embed_dims[i] != embed_dims[i + 1]:
                if i >= 2:
                    asub = True
                else:
                    asub = False
                network_down.append(
                    Embedding(
                        patch_size=down_patch_size, stride=down_stride,
                        padding=down_pad,
                        in_chans=embed_dims[i], embed_dim=embed_dims[i + 1],
                        resolution=res,
                        asub=asub,
                        act_layer=act_layer, norm_layer=norm_layer,
                    )
                )
        self.network_down_layers = nn.ModuleList(network_down)
        
        # build decoder layers
        self.network_up_layers = nn.ModuleList()
        self.concat_back_dim = nn.ModuleList()
        
        self.skip_activation = nn.ReLU()
        # [这里原有的 self.coatt = nn.ModuleList() 定义和 loop append 已被删除]
        
        embed_dim_reverse = embed_dims[::-1] 
        res_arr = res_arr[::-1]
        
        self.embed_dim_reverse = embed_dim_reverse
        for i in range(len(layers)):
            layers_reverse = layers[::-1] 
            skip_down_conv = nn.Conv2d(in_channels=2*embed_dim_reverse[i], out_channels=embed_dim_reverse[i], kernel_size=3, padding=1)
            # [删除 CCA 添加代码]

            if i > 0 :
                if i <= 2:
                    asub = True
                else:
                    asub = False
                self.network_up_layers.append(
                    Expanding(
                        patch_size=down_patch_size, stride=down_stride,
                        padding=down_pad,
                        in_chans=embed_dim_reverse[i-1], embed_dim=embed_dim_reverse[i],
                        resolution=res_arr[i-1],
                        resolution2 = res_arr[i],
                        asub=asub,
                        act_layer=act_layer, norm_layer=norm_layer,
                    )
                )

            network_up = eformer_block_up(embed_dim_reverse[i], i, layers_reverse,
                                  pool_size=pool_size, mlp_ratio=mlp_ratios,
                                  act_layer=act_layer, norm_layer=norm_layer,
                                  drop_rate=drop_rate,
                                  drop_path_rate=drop_path_rate,
                                  use_layer_scale=use_layer_scale,
                                  layer_scale_init_value=layer_scale_init_value,
                                  resolution=res_arr[i],
                                  vit_num=vit_num,
                                  e_ratios=self.e_ratios_reverse)
                
            self.network_up_layers.append(network_up)
            self.concat_back_dim.append(skip_down_conv)


        self.out_indices = [0, 2, 4, 6]
        for i_emb, i_layer in enumerate(self.out_indices):
            if i_emb == 0 and os.environ.get('FORK_LAST3', None):
                layer = nn.Identity()
            else:
                layer = norm_layer(embed_dims[i_emb])
            layer_name = f'norm{i_layer}'
            self.add_module(layer_name, layer)


    def cls_init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)


    def forward_tokens(self, x):
        outs = []
        for idx, block in enumerate(self.network_down_layers):
            x = block(x)
            if idx in self.out_indices:

                norm_layer = getattr(self, f'norm{idx}')
                x_out = norm_layer(x)
                outs.append(x_out)
        return x, outs
    
    def forward_features(self, x):
        x = self.patch_embed(x)
        x, x_downsample = self.forward_tokens(x)
        return x, x_downsample
    
    def forward_up_features(self,x,x_downsample):
        skip_conn = [0, 2, 4, 6]
        x_downsample_reverse = x_downsample[::-1]
        for idx, block in enumerate(self.network_up_layers):
            if idx not in skip_conn:
                x = block(x)
            else:
                # [核心修改：删除 CCA 逻辑，直接拼接]
                x = torch.cat([x, x_downsample_reverse[skip_conn.index(idx)]], 1)
                x = self.concat_back_dim[skip_conn.index(idx)](x)
                x = block(x)
        return x
    
    def up_sample(self, x):
        x = self.up(x)
        return x


    def forward(self, x):
        x, x_downsample = self.forward_features(x)
        x = self.forward_up_features(x, x_downsample)
        x = self.up_sample(x)
        x = self.output(x)

        if self.num_classes == 1:
            x = self.sig(x)
        return x

# if __name__ == "__main__":
#     try:
#         from thop import profile, clever_format
#     except ImportError:
#         print("请先安装 thop: pip install thop")
#         exit()

#     model = Eff_Unet(
#         layers=[2, 2, 3, 2], 
#         embed_dims=[64, 128, 256, 512],
#         mlp_ratios=4,
#         downsamples=[True, True, False, False],
#         pool_size=4,
#         norm_layer=nn.BatchNorm2d,
#         act_layer=nn.GELU,
#         num_classes=32,
#         down_patch_size=3,
#         down_stride=2,
#         down_pad=1,
#         drop_rate=0.1,
#         drop_path_rate=0.2,
#         use_layer_scale=True,
#         layer_scale_init_value=1e-5,
#         resolution=512,
#         stem_channel=10
#     ).cuda()
    
    # model.eval() 

    # input_tensor = torch.randn(1, 10, 512, 512).cuda()

    # print(f"正在计算 Params 和 FLOPs (Input: {input_tensor.shape})...")

    # flops, params = profile(model, inputs=(input_tensor, ), verbose=False)
    
    # flops_formatted, params_formatted = clever_format([flops, params], "%.3f")

    
    # print("=" * 30)
    # print(f"Model: Eff_Unet (CCA Removed)")
    # print(f"Input Shape: {input_tensor.shape}")
    # print(f"FLOPs: {flops_formatted}")
    # print(f"Params: {params_formatted}")
    # print("=" * 30)

    # print(model(input_tensor).shape)