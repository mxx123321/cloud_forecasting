import torch
import torch.nn as nn
import itertools
class Attention4D(torch.nn.Module):
    def __init__(self, dim=384, key_dim=32, num_heads=8,
                 attn_ratio=4,
                 act_layer=nn.ReLU):
        super().__init__()
        self.num_heads = num_heads
        self.scale = key_dim ** -0.5
        self.key_dim = key_dim
        self.nh_kd = nh_kd = key_dim * num_heads

        
     
        self.d = int(attn_ratio * key_dim)
        self.dh = int(attn_ratio * key_dim) * num_heads
   
        h = self.dh + nh_kd * 2
        self.q = nn.Sequential(nn.Conv2d(dim, self.num_heads * self.key_dim, 1),
                               nn.BatchNorm2d(self.num_heads * self.key_dim), )
        self.k = nn.Sequential(nn.Conv2d(dim, self.num_heads * self.key_dim, 1),
                               nn.BatchNorm2d(self.num_heads * self.key_dim), )
        self.v = nn.Sequential(nn.Conv2d(dim, self.num_heads * self.d, 1),
                               nn.BatchNorm2d(self.num_heads * self.d),
                               )
        self.v_local = nn.Sequential(nn.Conv2d(self.num_heads * self.d, self.num_heads * self.d,
                                               kernel_size=3, stride=1, padding=1, groups=self.num_heads * self.d),
                                     nn.BatchNorm2d(self.num_heads * self.d), )
        self.talking_head1 = nn.Conv2d(self.num_heads, self.num_heads, kernel_size=1, stride=1, padding=0)
        self.talking_head2 = nn.Conv2d(self.num_heads, self.num_heads, kernel_size=1, stride=1, padding=0)

        self.proj = nn.Sequential(act_layer(),
                                  nn.Conv2d(self.dh, dim, 1),
                                  nn.BatchNorm2d(dim), )
        self.pool_q = nn.AdaptiveAvgPool2d(output_size=(8, 8))

        

    def forward(self, x):  # x (B,N,C)
        B, C, H, W = x.shape
      
        
        # torch.Size([10, 256, 16, 16]) self.q(x) 1
        # torch.Size([10, 256, 256]) self.q(x) 2

        # [10, 256, 16, 16] => [10, 256, 16, 16] reshape => [10, h, 256/h, 16*16] =>

        # B, C, W, H => B, C, WH => B, h, C/h , WH => [B, h, WH, C/h]
        q_temp =  self.q(x)
        # q = q_temp.flatten(2).reshape(B, self.num_heads, -1, self.N).permute(0, 1, 3, 2)
        q = q_temp.flatten(2).reshape(B, self.num_heads, -1, H*W).permute(0, 1, 3, 2)

        q_agent = self.pool_q(q_temp).reshape(B, C, -1).reshape(B, self.num_heads, -1, 8*8).permute(0, 1, 3, 2)
        # q_temp: B, C, W, H； q_agent: B, C, W_p, H_p => B, C, W_p*H_p => B, h, C/h, W_p*H_p =>  B, h, W_p*H_p , C/h
        # q_agent final: B, h, W_p*H_p, C/h


        # B, C, W, H => B, C, WH => B, h, C/h , WH => [B, h, C/h, WH]
        k = self.k(x).flatten(2).reshape(B, self.num_heads, -1, H*W).permute(0, 1, 2, 3)

        q_agent_k = ((q_agent * self.scale) @ k ).softmax(dim=-1)
        #a_agent_k => [B, h, W_p*H_p, C/h] @ [B, h, C/h, WH] => [B, h, W_p*H_p, WH]

        #####################################################
        v = self.v(x)
        
        

        v_local = self.v_local(v)
        # B, C, W, H => B, C, WH => B, h, C/h , WH => [B, h, WH, C/h]
        v = v.flatten(2).reshape(B, self.num_heads, -1, H*W).permute(0, 1, 3, 2)
        

        q_agent_k_v = q_agent_k @ v
        #[B, h, W_p*H_p, WH] @ [B, h, WH, C/h] => [B, h, W_p*H_p, C/h]
        #q_agent_k_v: => [B, h, W_p*H_p, C/h]

        #q: [B, h, WH, C/h] 
        #q_agent.transpose(-2, -1): [B, h, W_p*H_p, C/h] => [B, h, C/h, W_p*H_p]
        q_attention = ((q * self.scale) @ q_agent.transpose(-2, -1)).softmax(dim=-1)
        #q_attention: [B, h, WH, C/h]  @  [B, h, C/h, W_p*H_p] => [B, h, WH, W_p*H_p]
        q_attention = self.talking_head1(q_attention)
        q_agent_k_v = self.talking_head2(q_agent_k_v)
        #[B, h, WH, W_p*H_p] @  [B, h, W_p*H_p, C/h] => [B, h, WH, C/h]
        q_att_q_agent_k_v = q_attention @ q_agent_k_v
        
       

        out = q_att_q_agent_k_v.transpose(2, 3).reshape(B, self.dh,  H, W) + v_local
        

        out = self.proj(out)
        return out

att = Attention4D(dim=32, key_dim=32, num_heads=8,
                 attn_ratio=4,
                 act_layer=nn.ReLU
                 ).cuda(1)
# tensor = torch.randn(1,32,32,32).cuda(1)
# print(att(tensor).shape)