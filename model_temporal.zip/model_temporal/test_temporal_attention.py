import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from timm.layers import DropPath, trunc_normal_  # 更新为最新的 timm 导入路径
from timm.layers import to_2tuple
import torch.fft 

# -----------------------------------------------------------------------
# 1. 球面几何位置编码 (SGE) - 建立地理空间一致性 [cite: 10, 102]
# -----------------------------------------------------------------------
class GeoEmbedding(nn.Module):
    def __init__(self, precomputed_path, embed_dim, num_freqs=8):
        super().__init__()
        if precomputed_path and os.path.exists(precomputed_path):
            coords = torch.load(precomputed_path)
            self.register_buffer('geo_coords', coords) 
        else:
            self.register_buffer('geo_coords', torch.zeros(3, 2748, 2748))

        freq_bands = 2.0 ** torch.linspace(0.0, num_freqs - 1, num_freqs)
        self.register_buffer('freq_bands', freq_bands)
        
        self.input_dim = 3 * 2 * num_freqs
        self.proj = nn.Sequential(
            nn.Conv2d(self.input_dim, embed_dim, kernel_size=1),
            nn.GELU(),
            nn.Conv2d(embed_dim, embed_dim, kernel_size=1)
        )

    def forward(self, x_img):
        B, _, H, W = x_img.shape
        coords = self.geo_coords.unsqueeze(0).expand(B, -1, -1, -1) 
        
        if (H != coords.shape[2]) or (W != coords.shape[3]):
            coords = F.interpolate(coords, size=(H, W), mode='bilinear', align_corners=False)

        feat = coords.unsqueeze(-1) * self.freq_bands.view(1, 1, 1, 1, -1)
        feat = torch.cat([torch.sin(feat), torch.cos(feat)], dim=-1)
        feat = feat.permute(0, 1, 4, 2, 3).reshape(B, -1, H, W)
        return self.proj(feat)

# -----------------------------------------------------------------------
# 2. 增强型频谱聚合器 (RSTD Core) - 时序频谱记忆池 [cite: 12, 13]
# -----------------------------------------------------------------------
class FreqAggregator(nn.Module):
    def __init__(self, dim, h, w, dropout=0.):
        super().__init__()
        self.dim = dim
        self.h = h
        self.w = w
        
        # 改进：增强时序记忆能力 - 权重累乘实现非线性频谱过滤
        self.freq_weight1 = nn.Parameter(torch.randn(1, dim, h, w // 2 + 1, 2) * 0.02)
        self.freq_weight2 = nn.Parameter(torch.randn(1, dim, h, w // 2 + 1, 2) * 0.02)
        self.freq_weight3 = nn.Parameter(torch.randn(1, dim, h, w // 2 + 1, 2) * 0.02)
        
        self.proj = nn.Linear(dim, dim)
        self.norm = nn.LayerNorm(dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, glb):
        B, C, H, W = x.shape
        x_fft = torch.fft.rfft2(x.float(), norm='ortho')
        
        # 时序缓存池累乘
        w1 = torch.view_as_complex(self.freq_weight1)
        w2 = torch.view_as_complex(self.freq_weight2)
        w3 = torch.view_as_complex(self.freq_weight3)
        weight = w1 * w2 * w3
        
        current_h, current_w_half = x_fft.shape[2], x_fft.shape[3]
        if weight.shape[2] != current_h or weight.shape[3] != current_w_half:
            weight = F.interpolate(
                torch.view_as_real(weight).permute(0, 3, 1, 2), 
                size=(current_h, current_w_half), 
                mode='bilinear', align_corners=True
            ).permute(0, 2, 3, 1).contiguous()
            weight = torch.view_as_complex(weight)

        # C 维度门控调制
        glb_gate = glb.transpose(1, 2).unsqueeze(-1)
        inf_fft = weight * glb_gate
        res_fft = x_fft * inf_fft
        
        res = torch.fft.irfft2(res_fft, s=(H, W), norm='ortho')
        update = res.mean(dim=(2, 3)).unsqueeze(1)
        update = self.proj(update)
        glb = self.norm(glb + self.dropout(update))
        return glb

# -----------------------------------------------------------------------
# 3. 改进型频谱注意力 - C 维度全局知识注入 [cite: 51, 52]
# -----------------------------------------------------------------------
class FreqAttention(nn.Module):
    def __init__(self, dim, h, w, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0.):
        super().__init__()
        self.dim = dim
        self.num_heads = num_heads
        self.scale = qk_scale or (dim // num_heads) ** -0.5

        self.glb_token = nn.Parameter(torch.randn(1, 1, dim))
        trunc_normal_(self.glb_token, std=.02)
        
        self.freq_aggregator = FreqAggregator(dim, h, w)

        # 改进：在通道维度拼接全局知识 [B, N, 2C] -> [B, N, C]
        self.fusion = nn.Linear(dim * 2, dim)
        
        self.q = nn.Linear(dim, dim, bias=qkv_bias)
        self.kv = nn.Linear(dim, dim * 2, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

    def forward(self, x):
        B, C, H, W = x.shape
        N = H * W
        glb = self.glb_token.expand(B, -1, -1) 
        glb = self.freq_aggregator(x, glb) 
        
        x_flat = x.flatten(2).transpose(1, 2) 
        print(glb.shape,"glb")
        # C 维度拼接：每个空间像素点都注入全局时序趋势提示 [cite: 13, 51]
        glb_ctx = glb.expand(-1, N, -1)
        print(glb_ctx.shape,"glb_ctx")
        print(x_flat.shape,"x_flat")
        x_fused = torch.cat([x_flat, glb_ctx], dim=-1) 
        print(x_fused.shape,"x_fused")
        x_q_in = self.fusion(x_fused) 
        
        q = self.q(x_q_in).reshape(B, N, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)
        kv = self.kv(x_q_in).reshape(B, N, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        k, v = kv[0], kv[1]

        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)

        x_out = (attn @ v).transpose(1, 2).reshape(B, N, C)
        x_out = self.proj(x_out)
        x_out = self.proj_drop(x_out)

        return x_out.transpose(1, 2).reshape(B, C, H, W)

# -----------------------------------------------------------------------
# 4. U-Net 基础组件与骨干网络
# -----------------------------------------------------------------------
class Mlp(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.fc1 = nn.Conv2d(in_features, hidden_features, 1)
        self.act = act_layer()
        self.fc2 = nn.Conv2d(hidden_features, out_features, 1)
        self.drop = nn.Dropout(drop)
        self.norm1 = nn.BatchNorm2d(hidden_features)
        self.norm2 = nn.BatchNorm2d(out_features)

    def forward(self, x):
        x = self.drop(self.act(self.norm1(self.fc1(x))))
        x = self.drop(self.norm2(self.fc2(x)))
        return x

class AttnFFN(nn.Module):
    def __init__(self, dim, mlp_ratio=4., act_layer=nn.GELU, drop=0., drop_path=0., resolution=7):
        super().__init__()
        self.token_mixer = FreqAttention(dim, h=resolution, w=resolution)
        self.mlp = Mlp(in_features=dim, hidden_features=int(dim * mlp_ratio), act_layer=act_layer, drop=drop)
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.layer_scale_1 = nn.Parameter(1e-5 * torch.ones(dim, 1, 1))
        self.layer_scale_2 = nn.Parameter(1e-5 * torch.ones(dim, 1, 1))

    def forward(self, x):
        x = x + self.drop_path(self.layer_scale_1 * self.token_mixer(x))
        x = x + self.drop_path(self.layer_scale_2 * self.mlp(x))
        return x

class Eff_Unet(nn.Module):
    def __init__(self, layers, embed_dims, stem_channel=10, num_classes=1, resolution=512, **kwargs):
        super().__init__()
        # Stem - 卫星数据投影
        self.patch_embed = nn.Sequential(
            nn.Conv2d(stem_channel, embed_dims[0]//2, 3, 2, 1), nn.BatchNorm2d(embed_dims[0]//2), nn.GELU(),
            nn.Conv2d(embed_dims[0]//2, embed_dims[0], 3, 2, 1), nn.BatchNorm2d(embed_dims[0]), nn.GELU()
        )
        # SGE 几何对齐注入 [cite: 9, 116]
        self.geo_embedding = GeoEmbedding(precomputed_path=None, embed_dim=embed_dims[0])
        
        # Encoder 层
        self.encoders = nn.ModuleList()
        curr_res = resolution // 4
        for i in range(len(layers)):
            # 每个阶段的 Transformer 块
            stage = nn.Sequential(*[AttnFFN(embed_dims[i], resolution=curr_res) for _ in range(layers[i])])
            self.encoders.append(stage)
            
            # 下采样层 (Embedding)
            if i < len(layers) - 1:
                down = nn.Sequential(
                    nn.Conv2d(embed_dims[i], embed_dims[i+1], 3, 2, 1),
                    nn.BatchNorm2d(embed_dims[i+1])
                )
                self.encoders.append(down)
                curr_res //= 2

        # Decoder & Output
        # 修复关键点：上采样的输入通道必须等于编码器最后一层的输出维度
        final_dim = embed_dims[-1]
        self.up = nn.Sequential(
            nn.ConvTranspose2d(final_dim, embed_dims[0], kernel_size=16, stride=16), # 直接上采样到 stem 尺度
            nn.BatchNorm2d(embed_dims[0]),
            nn.GELU()
        )
        self.output = nn.Conv2d(embed_dims[0], num_classes, kernel_size=1)

    def forward(self, x):
        # 空间路径：注入球面几何先验 [cite: 10, 118]
        x = self.patch_embed(x)
        x = x + self.geo_embedding(x)
        
        # 频谱趋势路径：RSTD 机制提取特征 [cite: 11, 47]
        for layer in self.encoders:
            x = layer(x)
            
        # 解码与输出
        x = self.up(x)
        return torch.sigmoid(self.output(x))

if __name__ == "__main__":
    # 配置与测试
    model = Eff_Unet(
        layers=[2, 2, 2], 
        embed_dims=[64, 128, 256], # 最后一层是 256
        stem_channel=10, 
        resolution=512,
        num_classes = 10
    ).cuda()
    
    dummy_input = torch.randn(1, 10, 512, 512).cuda()
    output = model(dummy_input)
    print(f"输入: {dummy_input.shape}")
    print(f"输出: {output.shape}") # 应为 [1, 1, 512, 512]