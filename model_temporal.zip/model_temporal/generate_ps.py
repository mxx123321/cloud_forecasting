import numpy as np
import torch
import os

# ================= 配置信息 =================
# 1. 你的查找表路径
RAW_FILE_PATH = "/data4/mxx_new_code/fengyun_mxx/Table/FY4B-_DISK_1050E_GEO_NOM_LUT_20240227000000_4000M_V0001.raw"
# 2. 输出保存路径
SAVE_PATH = "/data4/mxx_new_code/cloud_time_1024_jingjian/models/unet_attention_temporal/geo_coords_3d_improved.pt"

DIM = 2748

def generate_3d_coords_interleaved():
    print(f"正在以 Interleaved 格式读取: {RAW_FILE_PATH}")
    
    # 1. 读取原始数据
    raw_data = np.fromfile(RAW_FILE_PATH, dtype=np.float64)
    
    # 2. 按照交错格式解析
    # 取偶数索引为纬度，奇数索引为经度
    lat = raw_data[0:DIM*DIM*2:2].reshape(DIM, DIM)
    lon = raw_data[1:DIM*DIM*2:2].reshape(DIM, DIM)
    
    print(f"解析完成。原始中心点验证: Lat={lat[1374, 1374]:.4f}, Lon={lon[1374, 1374]:.4f}")

    # 3. 计算 3D 坐标
    # 子星点经度 (FY-4B 为 105.0)
    sub_lon = 105.0
    
    # 过滤背景 (背景通常是很大的无效值，如 9.999e+36)
    mask = (np.abs(lat) <= 90.1) & (np.abs(lon) <= 360)
    
    # --- 关键修改：计算相对经度 (dlon) ---
    # 这样可以确保：星下点 dlon = 0，西侧为负，东侧为正
    dlon = lon - sub_lon
    
    # 弧度转换
    lat_rad = np.deg2rad(np.where(mask, lat, 0))
    dlon_rad = np.deg2rad(np.where(mask, dlon, 0))

    # 转换为 3D 直角坐标 (单位球映射)
    # X: 深度感（中心为1，向四周减小），修正尺度畸变
    # Y: 左右感（中心为0，左负右正），修正位移速度
    # Z: 上下感（赤道为0，南负北正），修正扇形畸变
    x = np.cos(lat_rad) * np.cos(dlon_rad)
    y = np.cos(lat_rad) * np.sin(dlon_rad)
    z = np.sin(lat_rad)

    # 背景区域设为 0 (或者你可以设为 -1，取决于你模型的处理方式)
    x[~mask], y[~mask], z[~mask] = 0, 0, 0

    # 4. 保存为 Tensor
    # 堆叠后的形状为 [3, 2748, 2748]
    coords_3d = np.stack([x, y, z], axis=0).astype(np.float32)
    
    # 确保目录存在
    os.makedirs(os.path.dirname(SAVE_PATH), exist_ok=True)
    
    torch.save(torch.from_numpy(coords_3d), SAVE_PATH)
    print(f"成功保存修正后的 3D 坐标编码至: {SAVE_PATH}")
    print(f"修正后中心点验证 (应接近 1, 0, 0): X={x[1374, 1374]:.4f}, Y={y[1374, 1374]:.4f}, Z={z[1374, 1374]:.4f}")

if __name__ == "__main__":
    generate_3d_coords_interleaved()